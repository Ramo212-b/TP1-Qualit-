package tps.banque;

public class SensOperation {
	public static final String DEBIT = "OPERATION DE DEBIT";
	public static final String CREDIT = "OPERATION DE CREDIT";
}